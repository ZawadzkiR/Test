import time
import json
import subprocess
import urllib.request
import urllib.error

SERVER_BASE = "http://SERVER_DJANGO:8000"
AGENT_KEY = "WSTAW_AGENT_KEY_Z_PANELU"
POLL_SECONDS = 3

def _req(path, method="GET", body=None):
    url = SERVER_BASE + path
    data = None
    headers = {"X-AGENT-KEY": AGENT_KEY}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))

def main():
    hb = _req("/api/agent/heartbeat/", method="POST", body={})
    print("Połączono z agentem:", hb)
    cfg = _req("/api/agent/config/", method="POST", body={})
    interpreter = cfg.get("interpreter_path") or "python"
    print("Interpreter:", interpreter)

    while True:
        try:
            _req("/api/agent/heartbeat/", method="POST", body={})
            picked = _req("/api/agent/pick/", method="POST", body={})
            cmd = picked.get("command")
            if not cmd:
                time.sleep(POLL_SECONDS)
                continue

            print("=" * 80)
            print("Odebrano zadanie")
            print("ID:", cmd.get("id"))
            print("Opis:", cmd.get("description"))
            print("Typ:", cmd.get("command_type"))

            if cmd.get("command_type") == "python_argv":
                args = [interpreter, *cmd.get("argv", [])]
                print("Uruchamiam:", args)
                proc = subprocess.run(args, capture_output=True, text=True, shell=False)
            else:
                shell_command = cmd.get("shell_command", "")
                print("Uruchamiam shell_command:")
                print(shell_command)
                proc = subprocess.run(shell_command, capture_output=True, text=True, shell=True)

            print("Exit code:", proc.returncode)
            if proc.stdout:
                print("--- STDOUT ---")
                print(proc.stdout[-4000:])
            if proc.stderr:
                print("--- STDERR ---")
                print(proc.stderr[-4000:])

            _req("/api/agent/report/", method="POST", body={
                "id": cmd["id"],
                "exit_code": proc.returncode,
                "stdout": (proc.stdout or "")[-20000:],
                "stderr": (proc.stderr or "")[-20000:],
            })
        except urllib.error.HTTPError as e:
            try:
                body = e.read().decode("utf-8", errors="ignore")
            except Exception:
                body = ""
            print(f"Agent HTTP error: {e.code} {body}")
            time.sleep(5)
        except Exception as e:
            print("Agent error:", e)
            time.sleep(5)

if __name__ == "__main__":
    main()
