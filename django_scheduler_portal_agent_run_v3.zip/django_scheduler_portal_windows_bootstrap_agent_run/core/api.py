import json
from django.http import JsonResponse
from django.utils import timezone as dj_tz
from django.views.decorators.csrf import csrf_exempt
from core.models import Agent, ManualCommand, TaskRunLog

def _auth_agent(request):
    key = request.headers.get("X-AGENT-KEY", "")
    if not key:
        return None
    try:
        return Agent.objects.get(agent_key=key, is_active=True)
    except Agent.DoesNotExist:
        return None

@csrf_exempt
def agent_heartbeat(request):
    agent = _auth_agent(request)
    if agent is None:
        return JsonResponse({"error": "unauthorized"}, status=401)
    agent.last_seen_at = dj_tz.now()
    agent.save(update_fields=["last_seen_at"])
    return JsonResponse({"ok": True, "agent_id": agent.id})

@csrf_exempt
def agent_config(request):
    agent = _auth_agent(request)
    if agent is None:
        return JsonResponse({"error": "unauthorized"}, status=401)
    return JsonResponse({"ok": True, "interpreter_path": agent.interpreter_path})

@csrf_exempt
def agent_pick(request):
    agent = _auth_agent(request)
    if agent is None:
        return JsonResponse({"error": "unauthorized"}, status=401)
    cmd = ManualCommand.objects.filter(agent=agent, status="queued").order_by("created_at").first()
    if cmd is None:
        return JsonResponse({"ok": True, "command": None})
    cmd.status = "running"
    cmd.picked_at = dj_tz.now()
    cmd.save(update_fields=["status", "picked_at"])
    return JsonResponse({"ok": True, "command": {"id": cmd.id, "command_type": cmd.command_type, "description": cmd.description, "argv": cmd.argv_json, "shell_command": cmd.shell_command}})

@csrf_exempt
def agent_report(request):
    agent = _auth_agent(request)
    if agent is None:
        return JsonResponse({"error": "unauthorized"}, status=401)
    try:
        payload = json.loads(request.body.decode("utf-8"))
        cmd = ManualCommand.objects.get(id=int(payload["id"]), agent=agent)
        cmd.exit_code = int(payload.get("exit_code", -1))
        cmd.stdout = payload.get("stdout", "")
        cmd.stderr = payload.get("stderr", "")
        cmd.status = "done" if cmd.exit_code == 0 else "failed"
        cmd.finished_at = dj_tz.now()
        cmd.save()

        if cmd.task_id:
            TaskRunLog.objects.create(
                task=cmd.task,
                triggered_by=cmd.created_by,
                finished_at=dj_tz.now(),
                exit_code=cmd.exit_code,
                stdout=cmd.stdout,
                stderr=cmd.stderr,
                execution_target="agent",
                agent_name=agent.name,
            )
        return JsonResponse({"ok": True})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)
