Ta wersja naprawia:
- ręczne uruchomienie taska zapisujące execution_target/agent_name
- widoczność klucza agenta tylko raz
- brak ścieżki interpretera w tabeli agentów
- kolumnę Połączony z TAK/NIE
- agent wypisuje treść błędu HTTP 500

WAŻNE: Masz konflikt starej bazy z nowym modelem.
Najprościej zrób od zera:
1. zatrzymaj serwer i scheduler
2. usuń db.sqlite3
3. python manage.py migrate
4. python manage.py createsuperuser
5. python manage.py runserver
6. w drugim oknie: python manage.py run_scheduler

Jeżeli nie chcesz usuwać bazy, musiałbyś dopisać migracje ALTER TABLE do starego schematu.


Wersja v3:
- użytkownik może uruchamiać taski tylko przez swoich agentów
- agent loguje w konsoli, co uruchamia oraz stdout/stderr
