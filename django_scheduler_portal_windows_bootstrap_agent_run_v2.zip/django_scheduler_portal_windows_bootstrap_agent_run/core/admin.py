from django.contrib import admin
from core.models import Task, TaskRunLog, Agent, ManualCommand

admin.site.register(Task)
admin.site.register(TaskRunLog)
admin.site.register(Agent)
admin.site.register(ManualCommand)
