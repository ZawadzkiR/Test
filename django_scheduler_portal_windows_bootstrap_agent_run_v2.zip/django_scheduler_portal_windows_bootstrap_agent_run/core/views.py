import json
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django import forms
from django.utils import timezone as dj_tz
from core.models import Task, Agent, ManualCommand
from core.authz import manage_tasks_required, backup_restore_required, run_tasks_required
from core.scheduler import validate_cron, run_task_now
from core.services import export_tasks, import_tasks, generate_agent_key

ONLINE_SECONDS = 30

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ["name", "enabled", "cron", "command"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "enabled": forms.CheckboxInput(attrs={"class": "form-check-input"}),
            "cron": forms.TextInput(attrs={"class": "form-control", "placeholder": "*/5 * * * *"}),
            "command": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
        }

    def clean_cron(self):
        cron = self.cleaned_data["cron"]
        validate_cron(cron)
        return cron

class AgentForm(forms.ModelForm):
    class Meta:
        model = Agent
        fields = ["name", "interpreter_path", "is_active"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "interpreter_path": forms.TextInput(attrs={"class": "form-control", "placeholder": r"C:\Python310\python.exe"}),
            "is_active": forms.CheckboxInput(attrs={"class": "form-check-input"}),
        }

def _agent_queryset_for_user(user):
    qs = Agent.objects.filter(is_active=True)
    if not user.is_superuser:
        qs = qs.filter(owner=user)
    return qs

@login_required
def dashboard(request):
    return render(request, "core/dashboard.html", {"tasks_count": Task.objects.count(), "agents_count": Agent.objects.count() if request.user.is_superuser else Agent.objects.filter(owner=request.user).count()})

@login_required
@manage_tasks_required
def tasks_list(request):
    tasks = Task.objects.all().order_by("name")
    agents = list(_agent_queryset_for_user(request.user))
    now = dj_tz.now()
    for a in agents:
        a.is_online = bool(a.last_seen_at and (now - a.last_seen_at).total_seconds() <= ONLINE_SECONDS)
    return render(request, "core/tasks.html", {"tasks": tasks, "agents": agents})

@login_required
@manage_tasks_required
def task_create(request):
    form = TaskForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        obj = form.save(commit=False)
        obj.created_by = request.user
        obj.save()
        return redirect("core:tasks")
    return render(request, "core/task_form.html", {"form": form, "mode": "create"})

@login_required
@manage_tasks_required
def task_edit(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    form = TaskForm(request.POST or None, instance=task)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("core:tasks")
    return render(request, "core/task_form.html", {"form": form, "mode": "edit", "task": task})

@login_required
@manage_tasks_required
def task_delete(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method == "POST":
        task.delete()
        return redirect("core:tasks")
    return render(request, "core/task_delete.html", {"task": task})

@login_required
@run_tasks_required
def task_manual_run(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    if request.method != "POST":
        return HttpResponse("Method Not Allowed", status=405)
    target = request.POST.get("target", "server")
    if target == "server":
        run_task_now(task, triggered_by=request.user)
        return redirect("core:tasks")
    agent_id = request.POST.get("agent_id", "").strip()
    if not agent_id:
        return HttpResponse("Wybierz agenta", status=400)
    agent = get_object_or_404(Agent, id=agent_id, is_active=True)
    if not (request.user.is_superuser or agent.owner == request.user):
        return HttpResponse("Forbidden", status=403)
    ManualCommand.objects.create(agent=agent, task=task, created_by=request.user, description=f"Manual run task: {task.name}", command_type="shell", shell_command=task.command)
    return redirect("core:tasks")

@login_required
def agents_list(request):
    qs = Agent.objects.all() if request.user.is_superuser else Agent.objects.filter(owner=request.user)
    now = dj_tz.now()
    agents = list(qs.order_by("owner__username", "name"))
    for a in agents:
        a.is_online = bool(a.last_seen_at and (now - a.last_seen_at).total_seconds() <= ONLINE_SECONDS)
    return render(request, "core/agents.html", {"agents": agents})

@login_required
def agent_create(request):
    form = AgentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        a = form.save(commit=False)
        a.owner = request.user
        a.agent_key = generate_agent_key()
        a.show_key_once = True
        a.save()
        return redirect("core:agent_created", agent_id=a.id)
    return render(request, "core/agent_form.html", {"form": form, "mode": "create"})

@login_required
def agent_created(request, agent_id):
    agent = get_object_or_404(Agent, id=agent_id)
    if not (request.user.is_superuser or agent.owner == request.user):
        return HttpResponse("Forbidden", status=403)
    show_key = agent.show_key_once
    agent.show_key_once = False
    agent.save(update_fields=["show_key_once"])
    return render(request, "core/agent_created.html", {"agent": agent, "show_key": show_key})

@login_required
def agent_edit(request, agent_id):
    agent = get_object_or_404(Agent, id=agent_id)
    if not (request.user.is_superuser or agent.owner == request.user):
        return HttpResponse("Forbidden", status=403)
    form = AgentForm(request.POST or None, instance=agent)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("core:agents")
    return render(request, "core/agent_form.html", {"form": form, "mode": "edit", "agent": agent})

@login_required
def agent_regenerate_key(request, agent_id):
    agent = get_object_or_404(Agent, id=agent_id)
    if not (request.user.is_superuser or agent.owner == request.user):
        return HttpResponse("Forbidden", status=403)
    if request.method == "POST":
        agent.agent_key = generate_agent_key()
        agent.show_key_once = True
        agent.save(update_fields=["agent_key", "show_key_once"])
        return redirect("core:agent_created", agent_id=agent.id)
    return HttpResponse("Method Not Allowed", status=405)

@login_required
@backup_restore_required
def backup_view(request):
    if request.method == "POST":
        try:
            payload = json.loads(request.POST.get("payload", "[]"))
            import_tasks(payload)
            return redirect("core:backup")
        except Exception as e:
            return render(request, "core/backup.html", {"error": str(e), "export": json.dumps(export_tasks(), indent=2)})
    return render(request, "core/backup.html", {"export": json.dumps(export_tasks(), indent=2)})

@login_required
@run_tasks_required
def agent_manual_run(request, agent_id):
    agent = get_object_or_404(Agent, id=agent_id)
    if not (request.user.is_superuser or agent.owner == request.user):
        return HttpResponse("Forbidden", status=403)
    if request.method == "POST":
        argv = [x for x in request.POST.get("argv", "").strip().split(" ") if x]
        ManualCommand.objects.create(agent=agent, created_by=request.user, description=request.POST.get("description", ""), command_type="python_argv", argv_json=argv)
        return redirect("core:agents")
    return HttpResponse("Method Not Allowed", status=405)
