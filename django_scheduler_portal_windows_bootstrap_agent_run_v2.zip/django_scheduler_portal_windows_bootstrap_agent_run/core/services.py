import secrets
from core.models import Task

def generate_agent_key():
    return secrets.token_hex(32)

def export_tasks():
    return [{"name": t.name, "enabled": t.enabled, "cron": t.cron, "command": t.command} for t in Task.objects.all().order_by("name")]

def import_tasks(payload):
    for item in payload:
        Task.objects.update_or_create(
            name=item["name"],
            defaults={"enabled": bool(item.get("enabled", True)), "cron": item["cron"], "command": item["command"]},
        )
