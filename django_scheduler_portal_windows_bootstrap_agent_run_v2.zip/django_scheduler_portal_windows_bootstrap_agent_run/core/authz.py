from django.contrib.auth.decorators import permission_required

manage_tasks_required = permission_required("core.manage_tasks", raise_exception=True)
run_tasks_required = permission_required("core.run_tasks", raise_exception=True)
backup_restore_required = permission_required("core.backup_restore", raise_exception=True)
