import subprocess
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from croniter import croniter
from django.db import close_old_connections
from django.utils import timezone as dj_tz
from core.models import Task, TaskRunLog

_scheduler = None

def validate_cron(expr):
    parts = expr.strip().split()
    if len(parts) != 5:
        raise ValueError("Cron musi mieć 5 pól")
    if not croniter.is_valid(expr):
        raise ValueError("Niepoprawna składnia crontab")

def run_task_now(task, triggered_by=None):
    close_old_connections()
    log = TaskRunLog.objects.create(task=task, triggered_by=triggered_by, execution_target="server")
    try:
        proc = subprocess.run(task.command, shell=True, capture_output=True, text=True)
        log.exit_code = proc.returncode
        log.stdout = proc.stdout or ""
        log.stderr = proc.stderr or ""
    except Exception as e:
        log.exit_code = -1
        log.stderr = f"Exception: {e}"
    finally:
        log.finished_at = dj_tz.now()
        log.save()
    return log

def _run_task(task_id):
    run_task_now(Task.objects.get(id=task_id))

def get_scheduler():
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    sched = BackgroundScheduler(timezone="UTC")
    sched.start()
    _scheduler = sched
    return sched

def sync_jobs():
    sched = get_scheduler()
    for job in sched.get_jobs():
        if job.id.startswith("task:"):
            sched.remove_job(job.id)
    for task in Task.objects.filter(enabled=True):
        validate_cron(task.cron)
        minute, hour, day, month, dow = task.cron.split()
        trigger = CronTrigger(minute=minute, hour=hour, day=day, month=month, day_of_week=dow, timezone="UTC")
        sched.add_job(_run_task, trigger=trigger, id=f"task:{task.id}", replace_existing=True, kwargs={"task_id": task.id}, max_instances=1, coalesce=True)
