from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):
    name = models.CharField(max_length=200, unique=True)
    enabled = models.BooleanField(default=True)
    cron = models.CharField(max_length=100, help_text="Crontab: m h dom mon dow (np. '*/5 * * * *')")
    command = models.TextField(help_text="Komenda do uruchomienia na serwerze (cmd.exe / PowerShell).")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="tasks_created")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        permissions = [
            ("manage_tasks", "Can add/edit/delete tasks in GUI"),
            ("run_tasks", "Can trigger manual runs of tasks"),
            ("manage_agents", "Can manage agents"),
            ("backup_restore", "Can backup/restore tasks"),
        ]

    def __str__(self):
        return self.name

class TaskRunLog(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name="runs")
    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    exit_code = models.IntegerField(null=True, blank=True)
    stdout = models.TextField(blank=True, default="")
    stderr = models.TextField(blank=True, default="")
    triggered_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    execution_target = models.CharField(max_length=20, default="server", choices=[("server", "server"), ("agent", "agent")])
    agent_name = models.CharField(max_length=120, blank=True, default="")

class Agent(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="agents")
    name = models.CharField(max_length=120)
    agent_key = models.CharField(max_length=64, unique=True)
    interpreter_path = models.CharField(max_length=400, help_text="Ścieżka do python.exe na PC agenta")
    is_active = models.BooleanField(default=True)
    show_key_once = models.BooleanField(default=True)
    last_seen_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.owner.username} - {self.name}"

class ManualCommand(models.Model):
    agent = models.ForeignKey(Agent, on_delete=models.CASCADE, related_name="commands")
    task = models.ForeignKey(Task, on_delete=models.SET_NULL, null=True, blank=True, related_name="manual_commands")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    picked_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=30, default="queued", choices=[("queued","queued"),("running","running"),("done","done"),("failed","failed")])
    description = models.CharField(max_length=200, blank=True, default="")
    command_type = models.CharField(max_length=20, default="shell", choices=[("shell","shell"),("python_argv","python_argv")])
    argv_json = models.JSONField(default=list, blank=True)
    shell_command = models.TextField(blank=True, default="")
    exit_code = models.IntegerField(null=True, blank=True)
    stdout = models.TextField(blank=True, default="")
    stderr = models.TextField(blank=True, default="")
