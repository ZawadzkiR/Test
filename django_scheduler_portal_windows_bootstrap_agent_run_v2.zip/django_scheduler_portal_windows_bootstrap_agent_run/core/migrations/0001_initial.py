from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    initial = True
    dependencies = [("auth", "0012_alter_user_first_name_max_length")]

    operations = [
        migrations.CreateModel(
            name="Task",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=200, unique=True)),
                ("enabled", models.BooleanField(default=True)),
                ("cron", models.CharField(help_text="Crontab: m h dom mon dow (np. '*/5 * * * *')", max_length=100)),
                ("command", models.TextField(help_text="Komenda do uruchomienia na serwerze (cmd.exe / PowerShell).")),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("created_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="tasks_created", to="auth.user")),
            ],
            options={"permissions":[("manage_tasks","Can add/edit/delete tasks in GUI"),("run_tasks","Can trigger manual runs of tasks"),("manage_agents","Can manage agents"),("backup_restore","Can backup/restore tasks")]},
        ),
        migrations.CreateModel(
            name="Agent",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=120)),
                ("agent_key", models.CharField(max_length=64, unique=True)),
                ("interpreter_path", models.CharField(help_text="Ścieżka do python.exe na PC agenta", max_length=400)),
                ("is_active", models.BooleanField(default=True)),
                ("show_key_once", models.BooleanField(default=True)),
                ("last_seen_at", models.DateTimeField(blank=True, null=True)),
                ("owner", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="agents", to="auth.user")),
            ],
        ),
        migrations.CreateModel(
            name="TaskRunLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("started_at", models.DateTimeField(auto_now_add=True)),
                ("finished_at", models.DateTimeField(blank=True, null=True)),
                ("exit_code", models.IntegerField(blank=True, null=True)),
                ("stdout", models.TextField(blank=True, default="")),
                ("stderr", models.TextField(blank=True, default="")),
                ("execution_target", models.CharField(choices=[("server","server"),("agent","agent")], default="server", max_length=20)),
                ("agent_name", models.CharField(blank=True, default="", max_length=120)),
                ("task", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="runs", to="core.task")),
                ("triggered_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="auth.user")),
            ],
        ),
        migrations.CreateModel(
            name="ManualCommand",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("picked_at", models.DateTimeField(blank=True, null=True)),
                ("finished_at", models.DateTimeField(blank=True, null=True)),
                ("status", models.CharField(choices=[("queued","queued"),("running","running"),("done","done"),("failed","failed")], default="queued", max_length=30)),
                ("description", models.CharField(blank=True, default="", max_length=200)),
                ("command_type", models.CharField(choices=[("shell","shell"),("python_argv","python_argv")], default="shell", max_length=20)),
                ("argv_json", models.JSONField(blank=True, default=list)),
                ("shell_command", models.TextField(blank=True, default="")),
                ("exit_code", models.IntegerField(blank=True, null=True)),
                ("stdout", models.TextField(blank=True, default="")),
                ("stderr", models.TextField(blank=True, default="")),
                ("agent", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="commands", to="core.agent")),
                ("created_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="auth.user")),
                ("task", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="manual_commands", to="core.task")),
            ],
        ),
    ]
