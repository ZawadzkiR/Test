Uruchomienie aplikacji:
1. python -m venv .venv
2. .venv\Scripts\activate
3. pip install -r requirements.txt
4. python manage.py migrate
5. python manage.py createsuperuser
6. python manage.py runserver

W drugim oknie:
7. python manage.py run_scheduler

Agent:
1. Zaloguj się do panelu
2. Wejdź w Agenci -> Dodaj agenta
3. Ustaw nazwę, interpreter_path, zapisz
4. Skopiuj Agent key
5. Na komputerze agenta skopiuj plik agent_client\agent.py
6. Ustaw w agent.py:
   SERVER_BASE = "http://IP_SERWERA:8000"
   AGENT_KEY = "tu_wklej_agent_key"
7. Uruchom na komputerze agenta:
   python agent.py

Ręczne uruchomienie zadania:
- w tabeli Zadania kliknij "Uruchom ręcznie"
- wybierz:
  - Serwer -> wykona od razu na serwerze
  - Agent -> wyśle zadanie do wybranego agenta

Uwaga:
- agent wykonuje shell_command przez shell=True na swoim Windowsie
- czyli task.command może być np.:
  cmd /c dir
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Date"
