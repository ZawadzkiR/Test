#!/usr/bin/env python
import os, sys
def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE","scheduler_portal.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
if __name__=="__main__":
    main()
