Ta wersja dodaje:
1. stronę wyniku uruchomienia taska/kodu z błędem, stdout/stderr i statusem
2. osobną zakładkę "Kody ręczne" z odczytem argparse dla .py
3. widoczność tasków i kodów po grupach Django

Start od zera:
1. del db.sqlite3
2. python manage.py migrate
3. python manage.py createsuperuser
4. python manage.py runserver
5. w drugim oknie: python manage.py run_scheduler

Grupy:
- twórz w /admin/
- przypisz usera do grup
- przy tasku/kodzie wybierz grupy, które mają go widzieć

Kody ręczne:
- dodaj ścieżkę do pliku .py
- formularz odczyta add_argument z argparse
- uruchom przez serwer albo swojego agenta
