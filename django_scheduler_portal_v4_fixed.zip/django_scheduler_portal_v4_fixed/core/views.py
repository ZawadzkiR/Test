import json, subprocess, sys
from django import forms
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import Group
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone as dj_tz
from core.models import Task, TaskRunLog, Agent, ManualCommand, ScriptEntry, ScriptRunLog
from core.scheduler import validate_cron, run_task_now
from core.services import export_tasks, import_tasks, generate_agent_key, visible_tasks_for_user, visible_scripts_for_user
from core.utils import parse_argparse_from_file, build_argv_from_specs
ONLINE_SECONDS=30
class TaskForm(forms.ModelForm):
    visible_to_groups=forms.ModelMultipleChoiceField(queryset=Group.objects.all().order_by("name"),required=False,widget=forms.SelectMultiple(attrs={"class":"form-select"}))
    class Meta:
        model=Task; fields=["name","enabled","cron","command","visible_to_groups"]
        widgets={"name":forms.TextInput(attrs={"class":"form-control"}),"enabled":forms.CheckboxInput(attrs={"class":"form-check-input"}),"cron":forms.TextInput(attrs={"class":"form-control","placeholder":"*/5 * * * *"}),"command":forms.Textarea(attrs={"class":"form-control","rows":4})}
    def clean_cron(self): cron=self.cleaned_data["cron"]; validate_cron(cron); return cron
class AgentForm(forms.ModelForm):
    class Meta:
        model=Agent; fields=["name","interpreter_path","is_active"]
        widgets={"name":forms.TextInput(attrs={"class":"form-control"}),"interpreter_path":forms.TextInput(attrs={"class":"form-control"}),"is_active":forms.CheckboxInput(attrs={"class":"form-check-input"})}
class ScriptEntryForm(forms.ModelForm):
    visible_to_groups=forms.ModelMultipleChoiceField(queryset=Group.objects.all().order_by("name"),required=False,widget=forms.SelectMultiple(attrs={"class":"form-select"}))
    class Meta:
        model=ScriptEntry; fields=["name","path","description","visible_to_groups"]
        widgets={"name":forms.TextInput(attrs={"class":"form-control"}),"path":forms.TextInput(attrs={"class":"form-control"}),"description":forms.Textarea(attrs={"class":"form-control","rows":3})}
def _user_agents(user, active_only=True):
    qs=Agent.objects.all()
    if active_only: qs=qs.filter(is_active=True)
    if not user.is_superuser: qs=qs.filter(owner=user)
    return qs
def _mark_online(agents):
    now=dj_tz.now()
    for a in agents: a.is_online=bool(a.last_seen_at and (now-a.last_seen_at).total_seconds()<=ONLINE_SECONDS)
    return agents
def _dynamic_script_form(specs):
    fields={}
    for spec in specs:
        required=spec["required"] and spec["default"] is None and spec["action"]!="store_true"
        if spec["action"]=="store_true": fields[spec["name"]]=forms.BooleanField(required=False,label=spec["name"],help_text=spec.get("help",""))
        elif spec["choices"]:
            fields[spec["name"]]=forms.ChoiceField(required=required,choices=[(str(c),str(c)) for c in spec["choices"]],initial=None if spec["default"] is None else str(spec["default"]),label=spec["name"],help_text=spec.get("help",""))
        else:
            fields[spec["name"]]=forms.CharField(required=required,initial="" if spec["default"] is None else spec["default"],label=spec["name"],help_text=spec.get("help",""))
    DynamicForm=type("DynamicScriptForm",(forms.Form,),fields)
    for f in DynamicForm.base_fields.values():
        f.widget.attrs["class"]="form-check-input" if isinstance(f,forms.BooleanField) else "form-control"
    return DynamicForm
@login_required
def dashboard(request):
    return render(request,"core/dashboard.html",{"tasks_count":visible_tasks_for_user(request.user).count(),"scripts_count":visible_scripts_for_user(request.user).count(),"agents_count":_user_agents(request.user,active_only=False).count()})
@login_required
@permission_required("core.manage_tasks",raise_exception=True)
def tasks_list(request):
    return render(request,"core/tasks.html",{"tasks":visible_tasks_for_user(request.user).order_by("name"),"agents":_mark_online(list(_user_agents(request.user,active_only=True)))})
@login_required
@permission_required("core.manage_tasks",raise_exception=True)
def task_create(request):
    form=TaskForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        obj=form.save(commit=False); obj.created_by=request.user; obj.save(); form.save_m2m(); return redirect("core:tasks")
    return render(request,"core/task_form.html",{"form":form,"mode":"create"})
@login_required
@permission_required("core.manage_tasks",raise_exception=True)
def task_edit(request,task_id):
    task=get_object_or_404(Task,id=task_id); form=TaskForm(request.POST or None,instance=task)
    if request.method=="POST" and form.is_valid(): form.save(); return redirect("core:tasks")
    return render(request,"core/task_form.html",{"form":form,"mode":"edit","task":task})
@login_required
@permission_required("core.manage_tasks",raise_exception=True)
def task_delete(request,task_id):
    task=get_object_or_404(Task,id=task_id)
    if request.method=="POST": task.delete(); return redirect("core:tasks")
    return render(request,"core/task_delete.html",{"task":task})
@login_required
@permission_required("core.run_tasks",raise_exception=True)
def task_manual_run(request,task_id):
    task=get_object_or_404(visible_tasks_for_user(request.user),id=task_id)
    if request.POST.get("target","server")=="server":
        log=run_task_now(task,triggered_by=request.user); return redirect("core:task_run_detail",log_id=log.id)
    agent=get_object_or_404(_user_agents(request.user,active_only=True),id=request.POST.get("agent_id"))
    log=TaskRunLog.objects.create(task=task,triggered_by=request.user,execution_target="agent",agent_name=agent.name,status="queued")
    ManualCommand.objects.create(agent=agent,task=task,task_run_log=log,created_by=request.user,description=f"Manual run task: {task.name}",command_type="shell",shell_command=task.command)
    return redirect("core:task_run_detail",log_id=log.id)
@login_required
def task_run_detail(request,log_id):
    log=get_object_or_404(TaskRunLog.objects.select_related("task","triggered_by"),id=log_id)
    return render(request,"core/task_run_detail.html",{"log":log})
@login_required
@permission_required("core.manage_scripts",raise_exception=True)
def scripts_list(request):
    q=request.GET.get("q","").strip(); scripts=visible_scripts_for_user(request.user).order_by("name")
    if q: scripts=scripts.filter(name__icontains=q) | scripts.filter(path__icontains=q)
    return render(request,"core/scripts.html",{"scripts":scripts,"q":q})
@login_required
@permission_required("core.manage_scripts",raise_exception=True)
def script_create(request):
    form=ScriptEntryForm(request.POST or None)
    if request.method=="POST" and form.is_valid(): form.save(); return redirect("core:scripts")
    return render(request,"core/script_form.html",{"form":form,"mode":"create"})
@login_required
@permission_required("core.manage_scripts",raise_exception=True)
def script_edit(request,script_id):
    script=get_object_or_404(ScriptEntry,id=script_id); form=ScriptEntryForm(request.POST or None,instance=script)
    if request.method=="POST" and form.is_valid(): form.save(); return redirect("core:scripts")
    return render(request,"core/script_form.html",{"form":form,"mode":"edit","script":script})
@login_required
@permission_required("core.run_tasks",raise_exception=True)
def script_run(request,script_id):
    script=get_object_or_404(visible_scripts_for_user(request.user),id=script_id); specs=parse_argparse_from_file(script.path); DynamicForm=_dynamic_script_form(specs); form=DynamicForm(request.POST or None); agents=_mark_online(list(_user_agents(request.user,active_only=True)))
    if request.method=="POST" and form.is_valid():
        values=form.cleaned_data; argv=build_argv_from_specs(specs,values); target=request.POST.get("target","server")
        if target=="server":
            log=ScriptRunLog.objects.create(script=script,triggered_by=request.user,execution_target="server",status="running",used_args_json=values)
            try:
                proc=subprocess.run([sys.executable,script.path,*argv],capture_output=True,text=True)
                log.exit_code=proc.returncode; log.stdout=proc.stdout or ""; log.stderr=proc.stderr or ""; log.status="success" if proc.returncode==0 else "failed"
            except Exception as e:
                log.exit_code=-1; log.stderr=f"Exception: {e}"; log.status="failed"
            log.finished_at=dj_tz.now(); log.save(); return redirect("core:script_run_detail",log_id=log.id)
        agent=get_object_or_404(_user_agents(request.user,active_only=True),id=request.POST.get("agent_id"))
        log=ScriptRunLog.objects.create(script=script,triggered_by=request.user,execution_target="agent",status="queued",agent_name=agent.name,used_args_json=values)
        ManualCommand.objects.create(agent=agent,script=script,script_run_log=log,created_by=request.user,description=f"Manual run script: {script.name}",command_type="python_argv",argv_json=[script.path,*argv])
        return redirect("core:script_run_detail",log_id=log.id)
    return render(request,"core/script_run.html",{"script":script,"form":form,"agents":agents})
@login_required
def script_run_detail(request,log_id):
    return render(request,"core/script_run_detail.html",{"log":get_object_or_404(ScriptRunLog.objects.select_related("script","triggered_by"),id=log_id)})
@login_required
def agents_list(request): return render(request,"core/agents.html",{"agents":_mark_online(list(_user_agents(request.user,active_only=False).order_by("name")))})
@login_required
def agent_create(request):
    form=AgentForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        a=form.save(commit=False); a.owner=request.user; a.agent_key=generate_agent_key(); a.show_key_once=True; a.save(); return redirect("core:agent_created",agent_id=a.id)
    return render(request,"core/agent_form.html",{"form":form,"mode":"create"})
@login_required
def agent_created(request,agent_id):
    agent=get_object_or_404(Agent,id=agent_id,owner=request.user); show_key=agent.show_key_once; agent.show_key_once=False; agent.save(update_fields=["show_key_once"]); return render(request,"core/agent_created.html",{"agent":agent,"show_key":show_key})
@login_required
def agent_edit(request,agent_id):
    agent=get_object_or_404(Agent,id=agent_id,owner=request.user); form=AgentForm(request.POST or None,instance=agent)
    if request.method=="POST" and form.is_valid(): form.save(); return redirect("core:agents")
    return render(request,"core/agent_form.html",{"form":form,"mode":"edit","agent":agent})
@login_required
def agent_regenerate_key(request,agent_id):
    agent=get_object_or_404(Agent,id=agent_id,owner=request.user)
    if request.method=="POST": agent.agent_key=generate_agent_key(); agent.show_key_once=True; agent.save(update_fields=["agent_key","show_key_once"]); return redirect("core:agent_created",agent_id=agent.id)
    return HttpResponse("Method Not Allowed",status=405)
@login_required
@permission_required("core.backup_restore",raise_exception=True)
def backup_view(request):
    if request.method=="POST":
        try: import_tasks(json.loads(request.POST.get("payload","[]"))); return redirect("core:backup")
        except Exception as e: return render(request,"core/backup.html",{"error":str(e),"export":json.dumps(export_tasks(),indent=2)})
    return render(request,"core/backup.html",{"export":json.dumps(export_tasks(),indent=2)})
@login_required
@permission_required("core.run_tasks",raise_exception=True)
def agent_manual_run(request,agent_id):
    agent=get_object_or_404(_user_agents(request.user,active_only=False),id=agent_id)
    if request.method=="POST":
        argv=[x for x in request.POST.get("argv","").strip().split(" ") if x]
        ManualCommand.objects.create(agent=agent,created_by=request.user,description=request.POST.get("description",""),command_type="python_argv",argv_json=argv)
        return redirect("core:agents")
    return HttpResponse("Method Not Allowed",status=405)
