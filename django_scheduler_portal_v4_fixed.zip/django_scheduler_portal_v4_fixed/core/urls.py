from django.urls import path
from core import views, api
app_name="core"
urlpatterns=[
 path("",views.dashboard,name="dashboard"),
 path("tasks/",views.tasks_list,name="tasks"),
 path("tasks/new/",views.task_create,name="task_create"),
 path("tasks/<int:task_id>/edit/",views.task_edit,name="task_edit"),
 path("tasks/<int:task_id>/delete/",views.task_delete,name="task_delete"),
 path("tasks/<int:task_id>/manual-run/",views.task_manual_run,name="task_manual_run"),
 path("task-runs/<int:log_id>/",views.task_run_detail,name="task_run_detail"),
 path("scripts/",views.scripts_list,name="scripts"),
 path("scripts/new/",views.script_create,name="script_create"),
 path("scripts/<int:script_id>/edit/",views.script_edit,name="script_edit"),
 path("scripts/<int:script_id>/run/",views.script_run,name="script_run"),
 path("script-runs/<int:log_id>/",views.script_run_detail,name="script_run_detail"),
 path("agents/",views.agents_list,name="agents"),
 path("agents/new/",views.agent_create,name="agent_create"),
 path("agents/<int:agent_id>/created/",views.agent_created,name="agent_created"),
 path("agents/<int:agent_id>/edit/",views.agent_edit,name="agent_edit"),
 path("agents/<int:agent_id>/regen-key/",views.agent_regenerate_key,name="agent_regenerate_key"),
 path("agents/<int:agent_id>/manual-run/",views.agent_manual_run,name="agent_manual_run"),
 path("backup/",views.backup_view,name="backup"),
 path("api/agent/heartbeat/",api.agent_heartbeat,name="agent_heartbeat"),
 path("api/agent/config/",api.agent_config,name="agent_config"),
 path("api/agent/pick/",api.agent_pick,name="agent_pick"),
 path("api/agent/report/",api.agent_report,name="agent_report"),
]
