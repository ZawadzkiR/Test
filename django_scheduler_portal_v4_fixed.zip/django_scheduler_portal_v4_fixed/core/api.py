import json
from django.http import JsonResponse
from django.utils import timezone as dj_tz
from django.views.decorators.csrf import csrf_exempt
from core.models import Agent, ManualCommand
def _auth_agent(request):
    key=request.headers.get("X-AGENT-KEY","")
    try: return Agent.objects.get(agent_key=key,is_active=True)
    except Agent.DoesNotExist: return None
@csrf_exempt
def agent_heartbeat(request):
    agent=_auth_agent(request)
    if agent is None: return JsonResponse({"error":"unauthorized"},status=401)
    agent.last_seen_at=dj_tz.now(); agent.save(update_fields=["last_seen_at"])
    return JsonResponse({"ok":True,"agent_id":agent.id,"agent_name":agent.name})
@csrf_exempt
def agent_config(request):
    agent=_auth_agent(request)
    if agent is None: return JsonResponse({"error":"unauthorized"},status=401)
    return JsonResponse({"ok":True,"interpreter_path":agent.interpreter_path,"agent_name":agent.name})
@csrf_exempt
def agent_pick(request):
    agent=_auth_agent(request)
    if agent is None: return JsonResponse({"error":"unauthorized"},status=401)
    cmd=ManualCommand.objects.filter(agent=agent,status="queued").order_by("created_at").first()
    if cmd is None: return JsonResponse({"ok":True,"command":None})
    cmd.status="running"; cmd.picked_at=dj_tz.now(); cmd.save(update_fields=["status","picked_at"])
    if cmd.task_run_log_id: cmd.task_run_log.status="running"; cmd.task_run_log.save(update_fields=["status"])
    if cmd.script_run_log_id: cmd.script_run_log.status="running"; cmd.script_run_log.save(update_fields=["status"])
    return JsonResponse({"ok":True,"command":{"id":cmd.id,"description":cmd.description,"command_type":cmd.command_type,"argv":cmd.argv_json,"shell_command":cmd.shell_command}})
@csrf_exempt
def agent_report(request):
    agent=_auth_agent(request)
    if agent is None: return JsonResponse({"error":"unauthorized"},status=401)
    try:
        payload=json.loads(request.body.decode("utf-8")); cmd=ManualCommand.objects.get(id=int(payload["id"]),agent=agent)
        exit_code=int(payload.get("exit_code",-1)); stdout=payload.get("stdout",""); stderr=payload.get("stderr","")
        cmd.exit_code=exit_code; cmd.stdout=stdout; cmd.stderr=stderr; cmd.status="done" if exit_code==0 else "failed"; cmd.finished_at=dj_tz.now(); cmd.save()
        if cmd.task_run_log_id:
            log=cmd.task_run_log; log.exit_code=exit_code; log.stdout=stdout; log.stderr=stderr; log.status="success" if exit_code==0 else "failed"; log.finished_at=dj_tz.now(); log.agent_name=agent.name; log.execution_target="agent"; log.save()
        if cmd.script_run_log_id:
            log=cmd.script_run_log; log.exit_code=exit_code; log.stdout=stdout; log.stderr=stderr; log.status="success" if exit_code==0 else "failed"; log.finished_at=dj_tz.now(); log.agent_name=agent.name; log.execution_target="agent"; log.save()
        return JsonResponse({"ok":True})
    except Exception as e:
        return JsonResponse({"error":str(e)},status=400)
