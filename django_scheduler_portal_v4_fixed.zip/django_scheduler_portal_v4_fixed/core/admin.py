from django.contrib import admin
from core.models import Task, TaskRunLog, Agent, ManualCommand, ScriptEntry, ScriptRunLog
admin.site.register(Task); admin.site.register(TaskRunLog); admin.site.register(Agent); admin.site.register(ManualCommand); admin.site.register(ScriptEntry); admin.site.register(ScriptRunLog)
