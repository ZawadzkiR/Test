import time
from django.core.management.base import BaseCommand
from django.db.utils import OperationalError
from core.scheduler import sync_jobs, get_scheduler
class Command(BaseCommand):
    help="Uruchamia pętlę APScheduler"
    def handle(self,*args,**options):
        self.stdout.write("Start scheduler..."); get_scheduler()
        while True:
            try: sync_jobs()
            except OperationalError:
                self.stdout.write("Baza/migracje jeszcze niegotowe. Czekam 5 sekund..."); time.sleep(5); continue
            time.sleep(15)
