import ast
from pathlib import Path
def _literal(node, default=None):
    try: return ast.literal_eval(node)
    except Exception: return default
def parse_argparse_from_file(path: str) -> list[dict]:
    p=Path(path)
    if p.suffix.lower()!=".py" or not p.exists(): return []
    tree=ast.parse(p.read_text(encoding="utf-8"))
    args=[]
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr=="add_argument":
            spec={"name":None,"flags":[],"required":False,"default":None,"help":"","choices":None,"action":None,"positional":False}
            for a in node.args:
                val=_literal(a)
                if isinstance(val,str): spec["flags"].append(val)
            spec["positional"]=bool(spec["flags"] and not spec["flags"][0].startswith("-"))
            for kw in node.keywords:
                if kw.arg=="default": spec["default"]=_literal(kw.value)
                elif kw.arg=="required": spec["required"]=bool(_literal(kw.value,False))
                elif kw.arg=="help": spec["help"]=_literal(kw.value,"") or ""
                elif kw.arg=="choices": spec["choices"]=_literal(kw.value)
                elif kw.arg=="action": spec["action"]=_literal(kw.value)
            if spec["positional"]: spec["name"]=spec["flags"][0]
            else:
                lf=[f for f in spec["flags"] if f.startswith("--")]
                if lf: spec["name"]=lf[0].lstrip("-").replace("-","_")
                elif spec["flags"]: spec["name"]=spec["flags"][0].lstrip("-").replace("-","_")
            if spec["name"]: args.append(spec)
    out=[]; seen=set()
    for a in args:
        if a["name"] not in seen: out.append(a); seen.add(a["name"])
    return out
def build_argv_from_specs(specs,data):
    argv=[]
    for spec in specs:
        value=data.get(spec["name"])
        if spec["action"]=="store_true":
            if value: argv.append(next((f for f in spec["flags"] if f.startswith("--")), spec["flags"][0]))
            continue
        if value in (None,""): continue
        if spec["positional"]: argv.append(str(value))
        else:
            flag=next((f for f in spec["flags"] if f.startswith("--")), spec["flags"][0])
            argv.extend([flag,str(value)])
    return argv
