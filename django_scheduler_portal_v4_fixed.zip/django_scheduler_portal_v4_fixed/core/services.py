import secrets
from django.contrib.auth.models import Group
from django.db.models import Q
from core.models import Task, ScriptEntry
def generate_agent_key(): return secrets.token_hex(32)
def export_tasks():
    return [{"name":t.name,"enabled":t.enabled,"cron":t.cron,"command":t.command,"visible_to_groups":list(t.visible_to_groups.values_list("name",flat=True))} for t in Task.objects.all().order_by("name")]
def import_tasks(payload):
    for item in payload:
        task,_=Task.objects.update_or_create(name=item["name"],defaults={"enabled":bool(item.get("enabled",True)),"cron":item["cron"],"command":item["command"]})
        task.visible_to_groups.clear()
        for gname in item.get("visible_to_groups",[]):
            g,_=Group.objects.get_or_create(name=gname); task.visible_to_groups.add(g)
def visible_tasks_for_user(user):
    qs=Task.objects.all()
    return qs.distinct() if user.is_superuser else qs.filter(Q(visible_to_groups__isnull=True)|Q(visible_to_groups__in=user.groups.all())).distinct()
def visible_scripts_for_user(user):
    qs=ScriptEntry.objects.all()
    return qs.distinct() if user.is_superuser else qs.filter(Q(visible_to_groups__isnull=True)|Q(visible_to_groups__in=user.groups.all())).distinct()
